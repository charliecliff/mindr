//
//  MDRReminderContext.m
//  g5Mindr
//
//  Created by Charles Cliff on 6/18/16.
//  Copyright © 2016 Charles Cliff. All rights reserved.
//

#import "MDRReminderContext.h"

@implementation MDRReminderContext

- (NSDate *)currentDate {
    return [NSDate date];
}

@end
